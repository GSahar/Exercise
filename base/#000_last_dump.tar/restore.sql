--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.4
-- Dumped by pg_dump version 12.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE master_detail;
--
-- Name: master_detail; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE master_detail WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Russian_Russia.1251@icu' LC_CTYPE = 'Russian_Russia.1251';


\connect master_detail

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: document; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA document;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: documents; Type: TABLE; Schema: document; Owner: -
--

CREATE TABLE document.documents (
    s_number character varying NOT NULL,
    d_date date NOT NULL,
    s_description character varying,
    id numeric NOT NULL
);


--
-- Name: TABLE documents; Type: COMMENT; Schema: document; Owner: -
--

COMMENT ON TABLE document.documents IS 'Хранение списка документов';


--
-- Name: COLUMN documents.s_number; Type: COMMENT; Schema: document; Owner: -
--

COMMENT ON COLUMN document.documents.s_number IS 'Номер документ';


--
-- Name: COLUMN documents.d_date; Type: COMMENT; Schema: document; Owner: -
--

COMMENT ON COLUMN document.documents.d_date IS 'Дата документа';


--
-- Name: COLUMN documents.s_description; Type: COMMENT; Schema: document; Owner: -
--

COMMENT ON COLUMN document.documents.s_description IS 'Примечание';


--
-- Name: COLUMN documents.id; Type: COMMENT; Schema: document; Owner: -
--

COMMENT ON COLUMN document.documents.id IS 'Идентификатор документа';


--
-- Name: documents_detail; Type: TABLE; Schema: document; Owner: -
--

CREATE TABLE document.documents_detail (
    id_doc integer NOT NULL,
    s_name character varying NOT NULL,
    s_number character varying NOT NULL,
    id numeric NOT NULL,
    n_sum numeric DEFAULT 0.00
);


--
-- Name: COLUMN documents_detail.id_doc; Type: COMMENT; Schema: document; Owner: -
--

COMMENT ON COLUMN document.documents_detail.id_doc IS 'Идентификатор документа';


--
-- Name: COLUMN documents_detail.s_name; Type: COMMENT; Schema: document; Owner: -
--

COMMENT ON COLUMN document.documents_detail.s_name IS 'Наименование документа';


--
-- Name: COLUMN documents_detail.s_number; Type: COMMENT; Schema: document; Owner: -
--

COMMENT ON COLUMN document.documents_detail.s_number IS 'Номер документа';


--
-- Name: COLUMN documents_detail.id; Type: COMMENT; Schema: document; Owner: -
--

COMMENT ON COLUMN document.documents_detail.id IS 'Идентификатор строки документа';


--
-- Name: COLUMN documents_detail.n_sum; Type: COMMENT; Schema: document; Owner: -
--

COMMENT ON COLUMN document.documents_detail.n_sum IS 'Сумма позиции документа';


--
-- Name: seq_doc; Type: SEQUENCE; Schema: document; Owner: -
--

CREATE SEQUENCE document.seq_doc
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_doc_detail; Type: SEQUENCE; Schema: document; Owner: -
--

CREATE SEQUENCE document.seq_doc_detail
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying(200) NOT NULL,
    first_name character varying(255),
    last_name character varying(255)
);


--
-- Data for Name: documents; Type: TABLE DATA; Schema: document; Owner: -
--

COPY document.documents (s_number, d_date, s_description, id) FROM stdin;
\.
COPY document.documents (s_number, d_date, s_description, id) FROM '$$PATH$$/2895.dat';

--
-- Data for Name: documents_detail; Type: TABLE DATA; Schema: document; Owner: -
--

COPY document.documents_detail (id_doc, s_name, s_number, id, n_sum) FROM stdin;
\.
COPY document.documents_detail (id_doc, s_name, s_number, id, n_sum) FROM '$$PATH$$/2896.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, first_name, last_name) FROM stdin;
\.
COPY public.users (id, email, first_name, last_name) FROM '$$PATH$$/2900.dat';

--
-- Name: seq_doc; Type: SEQUENCE SET; Schema: document; Owner: -
--

SELECT pg_catalog.setval('document.seq_doc', 5, true);


--
-- Name: seq_doc_detail; Type: SEQUENCE SET; Schema: document; Owner: -
--

SELECT pg_catalog.setval('document.seq_doc_detail', 6, true);


--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hibernate_sequence', 1, false);


--
-- Name: documents_detail documents_detail_un; Type: CONSTRAINT; Schema: document; Owner: -
--

ALTER TABLE ONLY document.documents_detail
    ADD CONSTRAINT documents_detail_un UNIQUE (id_doc, s_number);


--
-- Name: documents_detail documents_detail_pk; Type: CONSTRAINT; Schema: document; Owner: -
--

ALTER TABLE ONLY document.documents_detail
    ADD CONSTRAINT documents_detail_pk PRIMARY KEY (id);


--
-- Name: documents documents_pk; Type: CONSTRAINT; Schema: document; Owner: -
--

ALTER TABLE ONLY document.documents
    ADD CONSTRAINT documents_pk PRIMARY KEY (id);


--
-- Name: documents documents_un; Type: CONSTRAINT; Schema: document; Owner: -
--

ALTER TABLE ONLY document.documents
    ADD CONSTRAINT documents_un UNIQUE (s_number);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: documents_detail_id_doc_idx; Type: INDEX; Schema: document; Owner: -
--

CREATE INDEX documents_detail_id_doc_idx ON document.documents_detail USING btree (id_doc);


--
-- Name: documents_detail documents_detail_fk; Type: FK CONSTRAINT; Schema: document; Owner: -
--

ALTER TABLE ONLY document.documents_detail
    ADD CONSTRAINT documents_detail_fk FOREIGN KEY (id_doc) REFERENCES document.documents(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

